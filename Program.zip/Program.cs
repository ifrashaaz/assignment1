﻿// See https://aka.ms/new-console-template for more information
using System;
public class Myclass
{
    public static void Main()
    {
        var name ="Ifra";
        Console.WriteLine($"Hello world this is {name}");
        Console.ReadKey();
    }
}

